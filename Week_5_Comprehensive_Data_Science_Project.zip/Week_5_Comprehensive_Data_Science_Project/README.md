# Comprehensive Data Science Project Reporting and Strategic Recommendations
**Author:** Sania Azaz | **Week:** 5

## Overview
End-to-end customer analytics project integrating data cleaning, exploratory analysis, visualization, statistical reasoning, model evaluation, and strategic recommendations.

## Dataset summary
- Usable records: 200
- Mean age: 43.2
- Mean annual income (k$): 78.0
- Mean spending score: 53.1
- Income-spending correlation: -0.15

## Files
- `Week_5_Comprehensive_Data_Science_Project_Report.docx`: full stakeholder report
- `Week_5_Technical_Coding_Documentation.docx`: technical workflow notes
- `week5_comprehensive_analysis.py`: analysis script
- `Mall_Customers_Week5_Source.csv`: source dataset
- `Mall_Customers_Week5_Prepared.csv`: cleaned dataset and derived features
- `visualizations/`: six charts
- `requirements.txt`: dependencies

## Run
```bash
pip install -r requirements.txt
python week5_comprehensive_analysis.py
```

## Recommendation
Use segments to form hypotheses, improve behavioral data, and validate campaigns with controlled experiments. Track incremental margin and customer-experience guardrails.

## Limitations
This is an educational analysis of a simplified dataset. It does not prove causation or measured business impact.
