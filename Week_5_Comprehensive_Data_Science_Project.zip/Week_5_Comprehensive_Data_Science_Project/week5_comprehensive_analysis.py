"""Week 5 comprehensive data science analysis | Author: Sania Azaz"""
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
BASE=Path(__file__).resolve().parent
df=pd.read_csv(BASE/"Mall_Customers_Week5_Source.csv")
df.columns=[c.strip() for c in df.columns]
for c in ["Age","Annual Income (k$)","Spending Score (1-100)"]:
    df[c]=pd.to_numeric(df[c],errors="coerce")
df=df.dropna(subset=["Age","Annual Income (k$)","Spending Score (1-100)"]).drop_duplicates()
df["AgeGroup"]=pd.cut(df["Age"],[17,25,35,50,100],labels=["18–25","26–35","36–50","51+"])
df["IncomeBand"]=pd.qcut(df["Annual Income (k$)"],4,labels=["Low","Mid","Upper-mid","High"],duplicates="drop")
df["HighSpender"]=(df["Spending Score (1-100)"]>=60).astype(int)
print("Records:",len(df))
print(df[["Age","Annual Income (k$)","Spending Score (1-100)"]].describe())
print("Income-spending correlation:",df["Annual Income (k$)"].corr(df["Spending Score (1-100)"]))
print(df.groupby("AgeGroup",observed=False)["Spending Score (1-100)"].mean())
out=BASE/"visualizations"; out.mkdir(exist_ok=True)
plt.figure(figsize=(7,4.5)); plt.scatter(df["Annual Income (k$)"],df["Spending Score (1-100)"])
plt.xlabel("Annual Income (k$)"); plt.ylabel("Spending Score"); plt.title("Income vs Spending Score")
plt.tight_layout(); plt.savefig(out/"01_income_vs_spending.png",dpi=150); plt.close()
